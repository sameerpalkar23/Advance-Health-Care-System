﻿# Advanced-Healthcare-System-using-Hybrid-Machine-Learning-Algorithms
### used the ui from @devmahmud github profile (https://github.com/devmahmud/Heart-Care-Django) and made my own modifications including ml algorithms etc

